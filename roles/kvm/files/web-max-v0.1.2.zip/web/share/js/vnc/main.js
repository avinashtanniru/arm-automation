
"use strict";


import { $, tools } from "../tools.js";


export function main() {
	__loadKvmdInfo();
}

function __loadKvmdInfo() {
	tools.httpGet("api/info", null, function (http) {
		switch (http.status) {
			case 200:
				__showKvmdInfo(JSON.parse(http.responseText).result);
				break;

			case 401:
			case 403:
				tools.currentOpen("login");
				break;

			default:
				setTimeout(__loadKvmdInfo, 1000);
				break;
		}
	});
}

function __showKvmdInfo(info) {
	$("vnc-text").innerHTML = `
		<span class="code-comment"># How to connect using the Linux terminal:<br>
		$</span> vncviewer ${tools.escape(window.location.hostname + "::" + info.extras.vnc.port)}
	`;
}
