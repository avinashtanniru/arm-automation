

"use strict";


import { ROOT_PREFIX } from "../vars.js";
import { tools, $ } from "../tools.js";
import { checkBrowser } from "../bb.js";
import { wm, initWindowManager } from "../wm.js";


export function main() {
	initWindowManager();

	if (checkBrowser(null, null)) {
		__loadKvmdInfo();
	}
}



function __loadKvmdInfo() {
	tools.httpGet("api/info", { "fields": "auth,meta,extras" }, function (http) {
		switch (http.status) {
			case 200:
				__showKvmdInfo(JSON.parse(http.responseText).result);
				break;

			case 401:
			case 403:
				tools.currentOpen("login");
				break;

			default:
				setTimeout(__loadKvmdInfo, 1000);
				break;
		}
	});
}

function __showKvmdInfo(info) {
	let apps = [];
	if (info.extras === null) {
		wm.error("Not all applications in the menu can be displayed due an error.<br>See KVMD logs for details.");
	} else {
		apps = Object.values(info.extras).sort(function (a, b) {
			if (a.place < b.place) {
				return -1;
			} else if (a.place > b.place) {
				return 1;
			} else {
				return 0;
			}
		});
	}

	let html = "";

	// Don't use this option, it may be removed in any time
	let hide_kvm_button = (
		(info.meta !== null && info.meta.web && info.meta.web.hide_kvm_button)
		|| tools.config.getBool("index--hide-kvm-button", false)
	);
	if (!hide_kvm_button) {
		html += __makeApp(null, "avm", "share/svg/kvm.svg", "AVM");
	}

	for (let app of apps) {
		if (app.place >= 0 && (app.enabled || app.started)) {
			html += __makeApp(null, app.path, app.icon, app.name);
		}
	}

	if (info.auth.enabled) {
		html += __makeApp("logout-button", "#", "share/svg/logout.svg", "Logout");
	}

	$("apps-box").innerHTML = `<ul id="apps">${html}</ul>`;

	if (info.auth.enabled) {
		tools.el.setOnClick($("logout-button"), __logout);
	}

	if (info.meta !== null && info.meta.server && info.meta.server.host) {
		$("kvmd-meta-server-host").innerText = info.meta.server.host;
		document.title = `${info.meta.server.host} | AVM Index`;
	} else {
		$("kvmd-meta-server-host").innerHTML = "<i>Invalid meta</i>";
		document.title = "AVM Index";
	}
}

function __makeApp(id, path, icon, name) {
	// Trailing slash in href is added to avoid Nginx 301 redirect
	// when the location doesn't have trailing slash: "foo -> foo/".
	// Reverse proxy can be misconfigured to handle this.
	// The "#" anchor (e.g. Logout) must not get a trailing slash.
	let e_add_id = (id ? `id="${tools.escape(id)}"` : "");
	let href = (path === "#" ? "#" : tools.escape(ROOT_PREFIX + path) + "/");
	return `<li>
		<div ${e_add_id} class="app">
			<a href="${href}">
				<span class="app-icon"><img class="svg-gray" src="${tools.escape(ROOT_PREFIX + icon)}"></span>
				<span class="app-name">${tools.escape(name)}</span>
			</a>
		</div>
	</li>`;
}

function __logout() {
	tools.httpPost("api/auth/logout", null, function (http) {
		switch (http.status) {
			case 200:
			case 401:
			case 403:
				tools.currentOpen("login");
				break;

			default:
				wm.error("Logout error", http.responseText);
				break;
		}
	});
}
