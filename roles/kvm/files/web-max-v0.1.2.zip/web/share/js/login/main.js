
"use strict";


import { tools, $ } from "../tools.js";
import { checkBrowser } from "../bb.js";
import { wm, initWindowManager } from "../wm.js";


export function main() {
	if (checkBrowser(null, null)) {
		initWindowManager();

		// Radio is a string container
		tools.radio.clickValue("expire-radio", tools.storage.get("login.expire", 0));
		tools.radio.setOnClick("expire-radio", function () {
			let expire = parseInt(tools.radio.getValue("expire-radio"));
			tools.storage.setInt("login.expire", expire);
		}, false);

		tools.el.setOnClick($("login-button"), __login);
		$("user-input").onkeyup = $("passwd-input").onkeyup = $("code-input").onkeyup = function (ev) {
			if (ev.code === "Enter") {
				ev.preventDefault();
				$("login-button").click();
			}
		};

		$("user-input").focus();
	}
}

function __login() {
	let e_user = encodeURIComponent($("user-input").value);
	if (e_user.length === 0) {
		$("user-input").focus();
		return;
	}

	let e_passwd = encodeURIComponent($("passwd-input").value + $("code-input").value);
	let e_expire = encodeURIComponent(tools.radio.getValue("expire-radio"));
	let body = `user=${e_user}&passwd=${e_passwd}&expire=${e_expire}`;

	tools.httpPost("api/auth/login", null, function (http) {
		switch (http.status) {
			case 200:
				tools.currentOpen("");
				break;

			case 403:
				wm.error("Invalid username, password, or OTP").then(__tryAgain);
				break;

			default: {
				let error = "";
				if (http.status === 400) {
					try {
						error = JSON.parse(http.responseText)["result"]["error"];
					} catch { /* Nah */ }
				}
				if (error === "ValidatorError") {
					wm.error("Invalid characters in credentials").then(__tryAgain);
				} else {
					wm.error("Unexpected login error:", http.responseText).then(__tryAgain);
				}
			} break;
		}
	}, body, "application/x-www-form-urlencoded");

	__setEnabled(false);
}

function __setEnabled(enabled) {
	tools.el.setEnabled($("user-input"), enabled);
	tools.el.setEnabled($("passwd-input"), enabled);
	tools.el.setEnabled($("code-input"), enabled);
	tools.el.setEnabled($("login-button"), enabled);
}

function __tryAgain() {
	__setEnabled(true);
	let el = ($("code-input").value.length ? $("code-input") : $("passwd-input"));
	el.focus();
	el.select();
}
