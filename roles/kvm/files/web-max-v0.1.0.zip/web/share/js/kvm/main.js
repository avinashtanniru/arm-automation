
"use strict";


import { tools, $ } from "../tools.js";
import { checkBrowser } from "../bb.js";
import { wm, initWindowManager } from "../wm.js";

import { Session } from "./session.js";


export function main() {
	if (checkBrowser(null, "kvm/x-mobile.css")) {
		tools.storage.bindSimpleSwitch($("page-close-ask-switch"), "page.close.ask", true, function (value) {
			if (value) {
				window.onbeforeunload = function (ev) {
					let text = "Are you sure you want to close PiKVM session?";
					if (ev) {
						ev.returnValue = text;
					}
					return text;
				};
			} else {
				window.onbeforeunload = null;
			}
		});

		initWindowManager();

		tools.el.setOnClick($("open-log-button"), () => tools.windowOpen("api/log?seek=3600&follow=1"));

		tools.storage.bindSimpleSwitch(
			$("page-full-tab-stream-switch"),
			"page.full_tab_stream",
			tools.config.getBool("kvm--full-tab-stream", false));
		if ($("page-full-tab-stream-switch").checked) {
			wm.setFullTabWindow($("stream-window"), true);
		}

		tools.storage.bindSimpleSwitch($("page-full-screen-frame-switch"), "page.full_screen_frame", false, function (value) {
			$("stream-fullscreen-active").classList.toggle("stream-fullscreen-bordered", value);
		});

		wm.showWindow($("stream-window"));

		new Session();
	}
}
