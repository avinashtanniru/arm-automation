
"use strict";


export var ROOT_PREFIX = "./";


export function setRootPrefix(prefix) {
	ROOT_PREFIX = prefix;
}
